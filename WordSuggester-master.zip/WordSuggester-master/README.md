# WordSuggester

#NetBeans_Project It is a java project which when you first start typing content,a list will display the suggestions below your text as you type. This means you can quickly select existing content from the list so that you do not have to finish typing it.Once you select the word and click on the search button, it will take you to the Google Search and displays results based on your selected word.

This application uses "TRIE DATA STRUCTURE" for storing and retrieving words efficiently from a file(Consists of all dictionary words) for suggestions.

This Application uses: 1.Swing controls 2.KeyListener(Key Released event) 3.ButtonActionPerformed event

![autosuggestionvideo](https://user-images.githubusercontent.com/26309884/28206041-254a1eba-68a2-11e7-8309-6cb9fa951b23.gif)

