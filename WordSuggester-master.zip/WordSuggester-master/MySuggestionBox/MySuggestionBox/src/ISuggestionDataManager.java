
import java.util.ArrayList;

public interface ISuggestionDataManager {
    ArrayList<String> getSuggestions(String prefix);
}
